Bickston Laenger, Araceli Rodriguez Vallejo, Aditya Raghavan, Juan Macias Romero, Alejandro Danies-Lopez 

In the GitHub folder, there is a pdf that has links to the GitHub repo from the original paper as well as a link to the paper itself, but the main link we used was the one on the bottom which led to tiny-big-bench-hard, which we took all of our JSON files for for the scripting.

In the results folder is an Excel spreadsheet that contains all of the inputs and outputs for each of the tasks and models. Each sheet has a different task on it.

In the samples folder is an example JSON file in there that we used as the input to the script to have it run through all the queries with each different model then there is also an example csv output from the scripts in there. After we made the csvs we then put the data from them into the master sheet found in results

In the scripts folder there is a script that we ran to run through all of the Ollama queries and submit everything in a csv, an example of which is shown in the samples folder. It requires having Ollama installed on the machine it is run on. There is also an analysis ipynb that we used to generate the graphs for the final report.

In the team contribution folder is a PDF that contains every persons team contribution. 

And in the outer folder there is the final report itself.